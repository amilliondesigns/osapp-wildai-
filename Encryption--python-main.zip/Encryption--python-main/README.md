# `Encrypt-python`
Cpython | encryption for python script | Hard to Decompile | Make python code unreadable 
[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Fira+Code&weight=700&duration=3000&pause=1000&width=435&lines=DON'T+FORGET+TO+STAR+THE+REPOSITORY+;THIS+TOOL+IS+BASICALLY+DESIGNED+;FOR+MAKING+CODE+UNREADABLE)](https://git.io/typing-svg)


[![Hits](https://hits.sh/github.com/hackesofice/SavingFromFormData.git.svg?style=plastic)](https://hits.sh/github.com/hackesofice/SavingFromFormData.git/)



`FOR ANDROID (TERMUX)`
```
pkg install python
pkg install git
pip install --upgrade cython
pip install requests
gem install lolcat
gem update --system 3.6.7
git clone https://github.com/hackesofice/Encrypt-python.git
cd Encrypt-python
python main.py
```

# `Next Plan's`

im still working on it to make it more accurate and secure 

# `Note`

keep in mind that everything is possible in this cyber world, so the Decompilation is also possible and we don't guarantee to protect your code and we aren't responsible for any types of controversys.


thank you 🙏 



# `Screenshot`

![img](https://raw.githubusercontent.com/hackesofice/Z/refs/heads/main/CPYTHON-TOOL/Screenshot.jpg)




<p>&copy 2025 hackesofice all rights reserved</p>
