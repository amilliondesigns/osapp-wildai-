import enc
